module module_laba_10 {
}