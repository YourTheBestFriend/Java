module module_laba_11 {
	exports laba_11;
}